package id.gudang.stokpys

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class CekStok : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_cek_stok)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Masuk Ke Menu Cek Stok Barcode
        val cekbarcode = findViewById<LinearLayout>(R.id.scanbarcode)
        cekbarcode.setOnClickListener {
            val intent = Intent(this, CekStokBarcode::class.java)
            startActivity(intent)
        }

        // Masuk Ke Menu Cek Stok Barcode
        val cekarticle = findViewById<LinearLayout>(R.id.cekarticle)
        cekarticle.setOnClickListener {
            val intent = Intent(this, CekStokArticle::class.java)
            startActivity(intent)
        }

        //Back ke Menu Awal
        val backkemenu = findViewById<ImageView>(R.id.backkemenu)
        backkemenu.setOnClickListener{
            val intent = Intent (this, Menu::class.java)
            startActivity(intent)
        }

    }
}