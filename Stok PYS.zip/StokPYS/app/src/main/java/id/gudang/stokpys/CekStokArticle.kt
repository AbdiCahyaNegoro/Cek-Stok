package id.gudang.stokpys

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import id.gudang.stokpys.data.StockDao
import id.gudang.stokpys.data.StockDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class CekStokArticle : AppCompatActivity() {
    private lateinit var stockDao: StockDao
    private lateinit var btnCekStok: Button
    private lateinit var etArticle: EditText
    private lateinit var tvArtStok: TextView
    private lateinit var tvNameDesc: TextView
    private lateinit var tvQuantity: TextView
    private lateinit var tvYard: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_cek_stok_article)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        //Back ke Menu Awal
        val backcekstok = findViewById<ImageView>(R.id.backkemenudariimport)
        backcekstok.setOnClickListener{
            val intent = Intent (this, CekStok::class.java)
            startActivity(intent)
        }

        // Inisialisasi UI
        btnCekStok = findViewById(R.id.btncariarticle)
        etArticle = findViewById(R.id.etArticle)
        tvArtStok = findViewById(R.id.Tvartstok)
        tvNameDesc = findViewById(R.id.textView19)
        tvQuantity = findViewById(R.id.textView25)
        tvYard = findViewById(R.id.textView26)

        // Inisialisasi DAO
        val database = StockDatabase.getDatabase(this)
        stockDao = database.stockDao()

        // Set onClickListener untuk tombol cek stok
        btnCekStok.setOnClickListener {
            val article = etArticle.text.toString().trim()

            if (article.isNotEmpty()) {
                cekStok(article)
            } else {
                Toast.makeText(this, "Masukkan Article yang valid!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Fungsi untuk cek stok berdasarkan article
    private fun cekStok(article: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val stockItem = stockDao.findByArticle(article)

                withContext(Dispatchers.Main) {
                    if (stockItem != null) {
                        // Menampilkan data stok ke UI
                        tvArtStok.text = stockItem.article
                        tvNameDesc.text = stockItem.namedescription
                        tvQuantity.text = stockItem.quantity.toString()
                        tvYard.text = stockItem.yard
                    } else {
                        Toast.makeText(this@CekStokArticle, "Stok tidak ditemukan!", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                Log.e("CekStokArticle", "Error mencari stok: ${e.message}", e)
            }
        }
    }
}
