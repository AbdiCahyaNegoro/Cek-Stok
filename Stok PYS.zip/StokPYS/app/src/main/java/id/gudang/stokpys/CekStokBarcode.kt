package id.gudang.stokpys

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.MultiFormatWriter
import com.google.zxing.WriterException
import com.google.zxing.common.BitMatrix
import com.google.zxing.integration.android.IntentIntegrator
import com.google.zxing.integration.android.IntentResult
import id.gudang.stokpys.data.StockDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.EnumMap

class CekStokBarcode : AppCompatActivity() {

    private lateinit var scanBarcodeButton: Button
    private lateinit var Tvbarstok: TextView
    private lateinit var textView19: TextView
    private lateinit var textView25: TextView
    private lateinit var textView26: TextView
    private lateinit var barcodeImageView: ImageView

    private lateinit var stockDatabase: StockDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_cek_stok_barcode)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Inisialisasi database
        stockDatabase = StockDatabase.getDatabase(this)

        // Back ke Menu Awal
        val backcekstok = findViewById<ImageView>(R.id.backkemenudaribarcode)
        backcekstok.setOnClickListener {
            val intent = Intent(this, CekStok::class.java)
            startActivity(intent)
        }

        scanBarcodeButton = findViewById(R.id.scanBarcodeButton)
        Tvbarstok = findViewById(R.id.Tvbarstok)
        textView19 = findViewById(R.id.textView19)
        textView25 = findViewById(R.id.textView25)
        textView26 = findViewById(R.id.textView26)
        barcodeImageView = findViewById(R.id.barcodeImageView)

        // Fungsi saat tombol scan ditekan
        scanBarcodeButton.setOnClickListener {
            startBarcodeScanner()
        }
    }

    // Memulai scan barcode
    private fun startBarcodeScanner() {
        val integrator = IntentIntegrator(this)
        integrator.setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES)
        integrator.setPrompt("Arahkan kamera ke barcode")
        integrator.setCameraId(0) // Kamera belakang
        integrator.setBeepEnabled(true)
        integrator.setBarcodeImageEnabled(true)
        integrator.initiateScan()
    }

    // Memproses hasil scan
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val result: IntentResult? = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
        if (result != null) {
            if (result.contents == null) {
                Toast.makeText(this, "Pemindaian dibatalkan", Toast.LENGTH_SHORT).show()
            } else {
                val scannedData: String = result.contents
                Tvbarstok.text = "Barcode: $scannedData" // Mengupdate UI dengan data yang discan
                val barcodeBitmap = generateBarcodeBitmap(scannedData)
                barcodeImageView.setImageBitmap(barcodeBitmap)

                // Cek stok berdasarkan barcode yang di-scan
                cekStokDariBarcode(scannedData)
            }
        }
    }

    private fun generateBarcodeBitmap(text: String): Bitmap? {
        val hintsMap: MutableMap<EncodeHintType, Any> = EnumMap(EncodeHintType::class.java)
        hintsMap[EncodeHintType.CHARACTER_SET] = "UTF-8"

        return try {
            val bitMatrix: BitMatrix = MultiFormatWriter().encode(
                text,
                BarcodeFormat.CODE_128,
                400,
                200,
                hintsMap
            )

            val width = bitMatrix.width
            val height = bitMatrix.height
            val pixels = IntArray(width * height)

            for (y in 0 until height) {
                val offset = y * width
                for (x in 0 until width) {
                    pixels[offset + x] = if (bitMatrix[x, y]) Color.BLACK else Color.WHITE
                }
            }

            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            bitmap.setPixels(pixels, 0, width, 0, 0, width, height)
            bitmap
        } catch (e: WriterException) {
            e.printStackTrace()
            null
        }
    }

    // Fungsi untuk cek stok berdasarkan barcode
    private fun cekStokDariBarcode(barcode: String) {
        CoroutineScope(Dispatchers.IO).launch {
            val stockItem = stockDatabase.stockDao().findByArticle(barcode) // Mengambil data dari database

            withContext(Dispatchers.Main) {
                if (stockItem != null) {
                    Tvbarstok.text = stockItem.article // Ganti sesuai dengan field nama barang di StockItem
                    textView19.text = stockItem.namedescription // Ganti sesuai dengan field nama barang di StockItem
                    textView25.text = stockItem.quantity.toString() // Ganti sesuai dengan field quantity di StockItem
                    textView26.text = stockItem.yard // Ganti sesuai dengan field unit di StockItem
                } else {
                    textView19.text = "Tidak Ditemukan"
                    textView25.text = "0"
                    textView26.text = "-"
                }
            }
        }
    }
}
