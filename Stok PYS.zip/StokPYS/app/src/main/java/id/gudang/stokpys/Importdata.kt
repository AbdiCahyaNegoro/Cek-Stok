package id.gudang.stokpys

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import id.gudang.stokpys.data.StockDao
import id.gudang.stokpys.data.StockDatabase
import id.gudang.stokpys.data.StockItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.apache.poi.ss.usermodel.WorkbookFactory

class Importdata : AppCompatActivity() {
    private lateinit var buttonImport: Button
    private lateinit var textViewStatus: TextView
    private lateinit var stockDao: StockDao

    companion object {
        private const val FILE_SELECT_CODE = 0
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_importdata)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        //Back Ke Menu
        val backkemenu = findViewById<ImageView>(R.id.backkemenudariimport)
        backkemenu.setOnClickListener{
            val intent = Intent (this, Menu::class.java)
            startActivity(intent)
        }

        // Inisialisasi DAO
        val database = StockDatabase.getDatabase(this)
        stockDao = database.stockDao()

        buttonImport = findViewById(R.id.button_import_excel)
        textViewStatus = findViewById(R.id.textView_status)

        // SAF untuk membuka file
        buttonImport.setOnClickListener {
            openFileChooser()
        }
    }

    // Gunakan SAF untuk memilih file
    private fun openFileChooser() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" // Untuk .xlsx
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/vnd.ms-excel",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            ))
        }
        startActivityForResult(intent, FILE_SELECT_CODE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == FILE_SELECT_CODE && resultCode == Activity.RESULT_OK) {
            data?.data?.let { uri ->
                readExcelFile(uri)
            } ?: run {
                Toast.makeText(this, "Tidak ada data yang dipilih", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun insertStockItem(stockItem: StockItem) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                stockDao.insert(stockItem)
                Log.d("ImportExcelActivity", "Item disimpan: ${stockItem.article}")
            } catch (e: Exception) {
                Log.e("ImportExcelActivity", "Error menyimpan item: ${e.message}", e)
            }
        }
    }

    private fun readExcelFile(uri: Uri) {
        try {
            Log.d("ImportExcelActivity", "Membuka file: $uri")
            contentResolver.openInputStream(uri)?.use { inputStream ->
                val workbook = WorkbookFactory.create(inputStream)
                val sheet = workbook.getSheetAt(0)
                val rowIterator = sheet.rowIterator()

                var itemCount = 0

                while (rowIterator.hasNext()) {
                    val row = rowIterator.next()

                    // Pastikan untuk memeriksa tipe data pada setiap cell
                    val article = if (row.getCell(0).cellType == org.apache.poi.ss.usermodel.CellType.STRING) {
                        row.getCell(0).stringCellValue ?: ""
                    } else {
                        row.getCell(0).numericCellValue.toString()
                    }

                    val namedescription = if (row.getCell(1).cellType == org.apache.poi.ss.usermodel.CellType.STRING) {
                        row.getCell(1).stringCellValue ?: ""
                    } else {
                        row.getCell(1).numericCellValue.toString()
                    }

                    val quantity = if (row.getCell(2).cellType == org.apache.poi.ss.usermodel.CellType.NUMERIC) {
                        row.getCell(2).numericCellValue.toInt()
                    } else {
                        row.getCell(2).stringCellValue.toIntOrNull() ?: 0
                    }

                    val yard = if (row.getCell(3).cellType == org.apache.poi.ss.usermodel.CellType.STRING) {
                        row.getCell(3).stringCellValue ?: ""
                    } else {
                        row.getCell(3).numericCellValue.toString()
                    }

                    // Buat objek StockItem
                    val stockItem = StockItem(
                        article = article,
                        namedescription = namedescription,
                        quantity = quantity,
                        yard = yard
                    )

                    // Simpan ke database
                    insertStockItem(stockItem)
                    itemCount++
                    Log.d("ImportExcelActivity", "Item diproses: $article, $namedescription, $quantity, $yard")
                }

                // Tampilkan Toast jika berhasil diimpor
                Log.i("ImportExcelActivity", "File berhasil diimpor.")
                textViewStatus.text = "File berhasil diimpor."
                showToast("File berhasil diimpor, $itemCount item ditambahkan.")

            }
        } catch (e: Exception) {
            Log.e("ImportExcelActivity", "Error membaca file: ${e.message}", e)
            Toast.makeText(this, "Error mengimpor file: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }


    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}