package id.gudang.stokpys

import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import id.gudang.stokpys.data.StockDao
import id.gudang.stokpys.data.StockDatabase // Pastikan Anda mengimpor database yang tepat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class Menu : AppCompatActivity() {

    private lateinit var stockDao: StockDao
    private lateinit var totaldata: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_menu)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Inisialisasi stockDao
        stockDao = StockDatabase.getDatabase(application).stockDao() // Sesuaikan dengan implementasi database Anda

        // Menampilkan Total Data di Database
        totaldata = findViewById(R.id.tvtotaldata)
        getTotalItems()

        // Masuk Ke Menu Semua Data
        val btn_semuadata = findViewById<LinearLayout>(R.id.Mn_semuadata)
        btn_semuadata.setOnClickListener {
            val intent = Intent(this, SemuaData::class.java)
            startActivity(intent)
        }

        // Masuk Ke Menu Cek Stok
        val btn_cekstok = findViewById<LinearLayout>(R.id.Mn_cekstok)
        btn_cekstok.setOnClickListener {
            val intent = Intent(this, CekStok::class.java)
            startActivity(intent)
        }

        // Masuk Ke Menu Import Data
        val btn_importdata = findViewById<LinearLayout>(R.id.Mn_importdata)
        btn_importdata.setOnClickListener {
            val intent = Intent(this, Importdata::class.java)
            startActivity(intent)
        }
    }

    private fun getTotalItems() {
        CoroutineScope(Dispatchers.IO).launch {
            val totalItems = stockDao.countItems()

            // Kembali ke thread utama untuk memperbarui UI
            withContext(Dispatchers.Main) {
                totaldata.text = totalItems.toString() // Menampilkan total item di TextView
            }
        }
    }
}