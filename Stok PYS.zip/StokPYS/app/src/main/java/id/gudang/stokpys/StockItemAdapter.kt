package id.gudang.stokpys

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import id.gudang.stokpys.data.StockItem

class StockItemAdapter(private val stockItems: List<StockItem>) :
    RecyclerView.Adapter<StockItemAdapter.StockItemViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StockItemViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_stock, parent, false)
        return StockItemViewHolder(view)
    }

    override fun onBindViewHolder(holder: StockItemViewHolder, position: Int) {
        val stockItem = stockItems[position]
        holder.bind(stockItem)
    }

    override fun getItemCount(): Int = stockItems.size

    class StockItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val textArticle: TextView = itemView.findViewById(R.id.text_article)
        private val textNamedescription: TextView = itemView.findViewById(R.id.text_namedescription)
        private val textQuantity: TextView = itemView.findViewById(R.id.text_quantity)
        private val textYard: TextView = itemView.findViewById(R.id.text_yard)

        fun bind(stockItem: StockItem) {
            textArticle.text = stockItem.article
            textNamedescription.text = stockItem.namedescription
            textQuantity.text = "Quantity: ${stockItem.quantity}"
            textYard.text = "Yard: ${stockItem.yard}"
        }
    }
}
