package id.gudang.stokpys.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface StockDao {
    @Insert
    suspend fun insert(stockItem: StockItem)

    @Insert
    suspend fun insertAll(stockItems: List<StockItem>)

    @Query("SELECT * FROM stock_items")
    suspend fun getAllItems(): List<StockItem>

    // Ubah return type dari StockItem menjadi Long untuk menghitung jumlah item
    @Query("SELECT COUNT(*) FROM stock_items")
    suspend fun countItems(): Long

    //mencari data by article
    @Query("SELECT * FROM stock_items WHERE article = :article LIMIT 1")
    suspend fun findByArticle(article: String): StockItem?

}
