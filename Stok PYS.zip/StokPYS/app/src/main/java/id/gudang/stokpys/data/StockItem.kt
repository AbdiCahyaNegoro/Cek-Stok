package id.gudang.stokpys.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stock_items")
data class StockItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val article: String,
    val namedescription: String,
    val quantity: Int,
    val yard: String
)
